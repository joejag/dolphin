#!/bin/bash

# Find and kill any openvpn process
kill $(ps -ef | grep openvpn | grep -v grep | grep -v run_dnsserv.sh | awk -F ' ' '{print $2}') >/dev/null 2>&1

# Find and kill any dnsserv.sh process
kill $(ps -ef | grep dnsserv | grep -v grep | grep -v kill_dnsserv.sh | grep -v run_dnsserv.sh | awk -F ' ' '{print $2}') >/dev/null 2>&1

# Starting Default DNS Server
systemctl enable systemd-resolved.service >/dev/null 2>&1
systemctl start systemd-resolved.service >/dev/null 2>&1

# Removing route to vpn concentrator
route del 185.109.9.29/32 >/dev/null 2>&1

# Removing Skype route via gateway
route del 185.109.10.14/32 >/dev/null 2>&1
