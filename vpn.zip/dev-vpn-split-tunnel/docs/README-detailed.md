# dev-vpn-split-tunnel

To provide RoS Dev VPN specific DNS Split Tunnelling to improve user experience on collaboration tools.

## Backgroud

RoS have historically used split tunnelling for Skype which has a RoS owned public IP address.

This allows a remote user to use their local gateway rather than tunnelling VOIP/Video traffic down a shared VPN which leads to improved performance and user experience.

The challenge of this approach with other tools such as slack is that RoS don't own the edge infrastructure and in some cases there may not be a small list of trusted IPs.

Slack runs on AWS and as such, using traditional IP based routing we'd have to split tunnel large portions of the AWS address space some of which may or may not be used by slack at an point in time.

This would open RoS networks up to the risk of malware using a Dev Client and VPN to attack the RoS network.

## Upstream

This repo is based on upstream https://github.com/RoliSoft/Split-Tunnel-Host which offers `Method 2` (see README-upstream.md) as a way to run a local dns server which will intercept dns requests and re write the routing table to send requests for those domains via a VPN.

This is the reverse of what we're looking for in that we want the default route to be the VPN tunnel adapter and to intercept DNS requests and re write the routing table to send those via the local gateway.

We'll therefore adapt this upstream repo for our own use.

## Adaptions

The following adaptions have been tested against Ubuntu 18.04 running a RoS Build

- run_dnsserver.sh updated to stop systemd-resolved.service to prevent a port conflict with the customised local dns server
- kill_dnsserver.sh updated to start systemd-resolved.service to ensure dns works again when the vpn is stopped
- the customised dns server is launched with arguments to ensure all upstream dns requests go to the rosdev dns servers (10.23.0.244 and 10.23.0.245)
- the customised dns server is launched with arguments to ensure the default gateway is the tunnel interface
- the customised dns server is launched with arguments to ensure the defined domains (rosdigital.slack.com) are routed via the local gaweway
- run_dnsserver.sh updated to support the old dev vpn rosdev or the new dev vpn openvpn which requires RSA based authentication

## Pre requisites

### Run as root

As the solution needs to make routing table updates it is **required that we run as root**. Open a terminal window and become root

### Forescout secure connector

ITSec have advised that in order to use this split tunnel solution they require that the client device be configured with the forescout secure
connection which will help to mitigate the risks of split tunneling configuration

https://gitlab.ros.gov.uk/iac/devclient/-/blob/master/ansible/playbooks/install-forescout.yml

```
git clone git@gitlab.ros.gov.uk:iac/devclient.git
cd devclient
sudo ansible-playbook --connection=local --inventory 127.0.0.1, ansible/playbooks/install-forescout.yml
```

## Setup/Usage Instructions

### Setup

- Clone the repo https://gitlab.ros.gov.uk/iac/dev-vpn-split-tunnel
  - `git clone git@gitlab.ros.gov.uk:iac/dev-vpn-split-tunnel.git`
- Find the location of your vpn setup folder via `find / -name *.ovpn`
- Copy the ros vpn files from your vpn setup folder in to the pia folder
  - For the legacy dev vpn:
    - `cp vpn_setup/ros* dev-vpn-split-tunnel/pia`
      - rosdev-ca.crt
      - rosdev-client.crt
      - rosdev-client.key
      - rosdev.ovpn
      - rosdev-ta.key
  - For the new openvpn dev vpn
    - `cp client.ovpn dev-vpn-split-tunnel/pia`

### Usage

If you were already using the vpn via network manager please disconnect it now

**NOTE** From this point you don't start and stop the vpn via network manager, the commands below will start and stop the vpn for you as well as running the custom dns server

- legacy vpn (rosdev)
  - `./run_dnsserv.sh rosdev`
- replacement openvpn (client)
  - `./run_dnsserv.sh client username`
  - you'll then be prompted to enter your rsa pin and token code
  - wait for it to refresh so that it does change while the script is running
  - if your pin is 1234 and your token code is 123456 then you enter 1234123456 and press enter
- stop the vpn from the dev-vpn-slit-tunnel directory via
  - `./kill_dnsserv.sh`

## Validation

While the vpn is connected

- Check that https://chat.ros.gov.uk works as expected
- Check that https://rosdigital.slack.com works as expected
- Test a slack call https://rosdigital.slack.com/help/test/calls
- use `route` command and check that we see routing table entries like server-xx-xx-xx via the the local (not tun interface)

## Troubleshooting

- dnsserv_out.txt has logs of the local custom dns process
- openvpn-out.txt has logs of the openvpn initialisation process
- if you run the `route` command and see delays then it indicates an issue with dns resolution, use `route -n` to skip name resolution

### if the vpn isn't cleaned up properly

`ps -ef | grep dns` will show the running dns processes, below are the processes you'd expect to see from this tooling

```
root     10672  2006  0 10:45 pts/0    00:00:00 /bin/bash ./run_dnsserv.sh rosdev
root     10894  2006  0 10:45 pts/0    00:00:00 ./dnsserv -r 192.168.1.1 -dp 10.23.0.244 -ds 10.23.0.244
```

we can use the kill command and the pids identified

`route` will show the tunnel interface which was established

e.g.

```
Destination     Gateway         Genmask         Flags Metric Ref    Use Iface
0.0.0.0         10.16.200.197   255.255.255.255 UGH   0      0        0 tun0
default         _gateway        0.0.0.0         UG    600    0        0 wlp4s0
ec2-3-9-202-151 _gateway        255.255.255.255 UGH   0      0        0 wlp4s0
10.0.17.0       10.16.200.197   255.255.255.0   UG    0      0        0 tun0
10.16.200.1     10.16.200.197   255.255.255.255 UGH   0      0        0 tun0
10.16.200.197   0.0.0.0         255.255.255.255 UH    0      0        0 tun0
10.22.2.0       10.16.200.197   255.255.255.0   UG    0      0        0 tun0
10.22.3.0       10.16.200.197   255.255.255.0   UG    0      0        0 tun0
10.23.0.0       10.16.200.197   255.255.0.0     UG    0      0        0 tun0
10.252.0.0      10.16.200.197   255.255.0.0     UG    0      0        0 tun0
10.253.0.0      10.16.200.197   255.255.252.0   UG    0      0        0 tun0
10.253.8.0      10.16.200.197   255.255.255.0   UG    0      0        0 tun0
10.253.16.0     10.16.200.197   255.255.255.0   UG    0      0        0 tun0
10.253.24.0     10.16.200.197   255.255.255.0   UG    0      0        0 tun0
10.254.0.0      10.16.200.197   255.255.0.0     UG    0      0        0 tun0
10.254.16.0     10.16.200.197   255.255.252.0   UG    0      0        0 tun0
server-13-224-7 _gateway        255.255.255.255 UGH   0      0        0 wlp4s0
server-13-224-7 _gateway        255.255.255.255 UGH   0      0        0 wlp4s0
server-13-224-7 _gateway        255.255.255.255 UGH   0      0        0 wlp4s0
server-13-224-7 _gateway        255.255.255.255 UGH   0      0        0 wlp4s0
server-13-224-2 _gateway        255.255.255.255 UGH   0      0        0 wlp4s0
server-13-224-2 _gateway        255.255.255.255 UGH   0      0        0 wlp4s0
server-13-224-2 _gateway        255.255.255.255 UGH   0      0        0 wlp4s0
server-13-224-2 _gateway        255.255.255.255 UGH   0      0        0 wlp4s0
ec2-35-176-156- _gateway        255.255.255.255 UGH   0      0        0 wlp4s0
server-52-84-13 _gateway        255.255.255.255 UGH   0      0        0 wlp4s0
server-52-84-13 _gateway        255.255.255.255 UGH   0      0        0 wlp4s0
server-52-84-13 _gateway        255.255.255.255 UGH   0      0        0 wlp4s0
server-52-84-13 _gateway        255.255.255.255 UGH   0      0        0 wlp4s0
server-99-86-11 _gateway        255.255.255.255 UGH   0      0        0 wlp4s0
server-99-86-11 _gateway        255.255.255.255 UGH   0      0        0 wlp4s0
server-99-86-11 _gateway        255.255.255.255 UGH   0      0        0 wlp4s0
server-99-86-11 _gateway        255.255.255.255 UGH   0      0        0 wlp4s0
server-99-86-25 _gateway        255.255.255.255 UGH   0      0        0 wlp4s0
server-99-86-25 _gateway        255.255.255.255 UGH   0      0        0 wlp4s0
server-99-86-25 _gateway        255.255.255.255 UGH   0      0        0 wlp4s0
server-99-86-25 _gateway        255.255.255.255 UGH   0      0        0 wlp4s0
link-local      0.0.0.0         255.255.0.0     U     1000   0        0 wlp4s0
192.168.1.0     0.0.0.0         255.255.255.0   U     600    0        0 wlp4s0
```

we can kill that tunnel interface via `ifconfig` e.g. `ifconfig tun0 down`

## Known issues

On Ubuntu 16 it was dnsmasq rather than systemd-resolved which ran as the deafult dns service on port 53.  
If you're still running Ubuntu16 the auto stop/start of your default dns service will not work.  
You will have to disable dnsmasq as per https://unix.stackexchange.com/questions/257274/how-to-disable-dnsmasq
