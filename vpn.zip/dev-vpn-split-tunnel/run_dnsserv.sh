#!/bin/bash

echo "   ___       ____  ______                   ____       "
echo "  / _ \___  / __/ /_  __/_ _____  ___  ___ / / /__ ____"
echo " / , _/ _ \_\ \    / / / // / _ \/ _ \/ -_) / / -_) __/"
echo "/_/|_|\___/___/   /_/  \_,_/_//_/_//_/\__/_/_/\__/_/   "
echo "                                                       "
echo -e "                                           V:\e[33m" $(git log --pretty=format:'%h' -n 1) "\e[0m"
echo ""

if [ $# == 1 ]; then
    vpn_type="rosdev"
elif [ $# == 2 ]; then
    vpn_type="openvpn"
else
    echo "usage: run_dnsserv.sh rosdev"
    echo "usage: run_dnsserv.sh client [username]"
    exit 1
fi

if [ ! -f "pia/$1.ovpn" ]; then
    echo "pia/$1.ovpn does not exist. Copy the your VPN files to this location first"
    exit 1
fi

if [ $EUID -ne 0 ]; then
    echo "This script must be run as root"
    exit 1
fi

echo " 1. Cleaning up any existing sessions and broken DNS"
./cleanup.sh

# Stopping default DNS Server
systemctl disable systemd-resolved.service >/dev/null 2>&1
systemctl stop systemd-resolved.service >/dev/null 2>&1
# Assume the current DNS is broken. Reset to a known good DNS nameserver
echo "nameserver 1.1.1.1" > /etc/resolv.conf
sleep 1

if lsof -i :53 | grep LISTEN  >/dev/null 2>&1 ; then
    echo -e "\n  FAILED!"
    echo -e "\nSomething is running on port \e[33m53\e[0m on your machine. You need to disable this service before we can progress\n"
    lsof -i :53
    echo -e "\nSometimes on Ubuntu 16 it is because the NetworkManager is running a local DNS. You can check and fix this by"
    echo -e "1. sudo nano /etc/NetworkManager/NetworkManager.conf"
    echo -e "   check under [Main] to see if dns is set to \e[33mdns=none\e[0m if not change it to that"
    echo -e "2. systemctl restart NetworkManager.service"
    echo -e "3. sudo nano /etc/resolv.conf"
    echo -e "   change it's contents to \e[33mnameserver 1.1.1.1\e[0m"
    echo -e "4. Run this script again."
    exit 1
fi


default_interface=$(ip route show | grep default | cut -d " " -f 5 | head -1)
default_gateway=$(ip route show | grep default | cut -d " " -f 3 | head -1)
echo -e " 2. Current Gateway: \e[33m$default_gateway\e[0m"

echo " 3. Starting VPN connection"
echo ""
rm -f openvpn_out.txt

if [ $vpn_type == "rosdev" ]; then
    ( cd pia; openvpn --writepid ../openvpn_pid.txt --config "$1.ovpn" --route-metric 50 --script-security 2 > ../openvpn_out.txt 2>&1 )&
elif [ $vpn_type == "openvpn" ]; then
    echo "    Enter your RSA pin + token code"

    # Mask input using approach from https://stackoverflow.com/questions/1923435/how-do-i-echo-stars-when-reading-password-with-read
    unset rsa_pin_and_token_code
    while IFS= read -p "$prompt" -r -s -n 1 char
    do
        if [[ $char == $'\0' ]]
        then
            break
        fi
        prompt='*'
        rsa_pin_and_token_code+="$char"
    done
    echo ""

    if [ ${#rsa_pin_and_token_code} -eq 0 ]; then
        echo -e "\e[91m No pin was given. Please check your numpad is on"
        exit
    fi

    credstring=$2"\n"$rsa_pin_and_token_code
    ( cd pia; openvpn --writepid ../openvpn_pid.txt --config "$1.ovpn" --route-metric 50 --auth-user-pass <(echo -e "${credstring}") > ../openvpn_out.txt 2>&1 )&
fi

vpn_ip_address=
until [ ! -z ${vpn_ip_address} ]; do
    printf "."
    
    if [ -f openvpn_out.txt ]; then
        if [ $vpn_type == "rosdev" ]; then
            vpn_ip_address=$(cat openvpn_out.txt | grep -Po '(?<=[0-9\.]{7} peer )[0-9\.]{4,}')
        elif [ $vpn_type == "openvpn" ]; then
            vpn_ip_address=$(cat openvpn_out.txt | grep -Po '(?<=route-gateway )[0-9\.]{4,}')
        fi
    fi
    
    sleep 1
    
    if [ ! -f openvpn_pid.txt ]; then
        echo "OpenVPN failed to run:"
        cat openvpn_out.txt
        exit 1
    fi

    if [ -f openvpn_out.txt ]; then
      if grep -q AUTH_FAILED openvpn_out.txt; then
        echo 
        echo 
        echo -e " \e[91m\u2718 OpenVPN indicated your pin was incorrect OR your account is locked\e[0m"
        echo -e "   * First: Try running this program again"
        echo -e "   * If that fails: Go to \e[33mhttps://access.ros.gov.uk\e[0m to try logging in there"
        echo -e "     * If that works, try running this program again"
        echo -e "     * If that fails, then your account is locked and you need to phone the Service Desk"
        exit 1
      fi
    fi
done

echo ""
echo ""
echo -e " 4. Connected with IP: \e[33m$vpn_ip_address\e[0m"

echo " 5. Switching to local DNS"
rm -f dnsserv_out.txt
./dnsserv -r "$default_gateway" -dp "10.23.0.244" -ds "10.23.0.245" > dnsserv_out.txt 2>&1 &

sleep 1

echo "nameserver 127.0.0.1" > /etc/resolv.conf

# Switching to DNS server...
test -f /etc/init.d/dnsmasq && /etc/init.d/dnsmasq restart >/dev/null 2>&1

# Setting default route via tunnel
route add default gw $vpn_ip_address netmask 0.0.0.0 metric 50

# Setting vpn concentrator route via gateway
route add 185.109.9.29/32 gw $default_gateway metric 600

# Setting Skype route via gateway
route add 185.109.10.14/32 gw $default_gateway metric 600

echo " 6. Validating configuration"
all_fine="true"

# 1. Make sure resolv.conf is correct
expected_resolve="nameserver 127.0.0.1"
if [ "$expected_resolve" != "$(cat /etc/resolv.conf)" ]; then
    echo -e "    \e[91m\u2718 /etc/resolv.conf\e[0m should be 127.0.0.1 but isn't"
    all_fine="false"
else
    echo -e "    \e[32m\u2714 /etc/resolv.conf\e[0m is pointing to local DNS"
fi

# 2. Make sure Slack etc go to the right hosts
vpn_interface=$(ip route show | grep default | cut -d " " -f 5 | head -1)
function testConnection() {
    host=$1
    expected_interface=$2
    # Use dig to get ip address, sometimes we get CNAMEs rather than just A addresses, so sorting to prefer them
    host_ip=$(dig +short "$host" | sort | head -1 | awk '{print $1; exit}')
    inteface_being_used=$(ip route get "$host_ip" | grep -Po '(?<=(dev )).*(?= src| proto)' | xargs)
    if [ "$expected_interface" == "$inteface_being_used" ]; then
        echo -e "    \e[32m\u2714 $host\e[0m is using \e[33m$expected_interface\e[0m as expected"
    else
        echo -e "    \e[91m\u2718 $host\e[0m should be using \e[33m$expected_interface\e[0m but is using \e[33m$inteface_being_used\e[0m"
        all_fine="false"
    fi
}

testConnection "google.com" $vpn_interface

if [ "$all_fine" == "true" ]; then
    echo " 7. All done, get to work"
    echo -e "    When you're done, you can disconnect the VPN with \e[33msudo ./kill_dnsserv.sh\e[0m"
else
    echo ""
    echo "  FAILED!"
    ./debug.sh
fi