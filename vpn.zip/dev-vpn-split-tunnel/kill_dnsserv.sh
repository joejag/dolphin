#!/bin/bash

echo "   ___       ____  ______                   ____       "
echo "  / _ \___  / __/ /_  __/_ _____  ___  ___ / / /__ ____"
echo " / , _/ _ \_\ \    / / / // / _ \/ _ \/ -_) / / -_) __/"
echo "/_/|_|\___/___/   /_/  \_,_/_//_/_//_/\__/_/_/\__/_/   "
echo "                                                       "
echo -e "                                           V:\e[33m" $(git log --pretty=format:'%h' -n 1) "\e[0m"
echo ""

if [ $EUID -ne 0 ]; then
    echo "This script must be run as root"
    exit 1
fi

echo " 1. Switching DNS back a non-VPN host"
echo "nameserver 1.1.1.1" > /etc/resolv.conf

echo " 2. Killing VPN and local DNS server"
./cleanup.sh

echo " 3. Making sure your system is good to go"

google_good="false"
vpn_good="false"
function check_connections() {
    if nc -z google.com 443 -w 3 >/dev/null 2>&1 ; then
        echo -e "    \e[32m\u2714\e[0m google.com"
        vpn_good="true"
    else
        echo -e "    \e[91m\u2718\e[0m google.com"
        vpn_good="false"
    fi

    if nc -z vpn.ros.gov.uk 443 -w 3 >/dev/null 2>&1 ; then
        echo -e "    \e[32m\u2714\e[0m vpn.ros.gov.uk"
        google_good="true"
    else
        echo -e "    \e[91m\u2718\e[0m vpn.ros.gov.uk"
        google_good="false"
    fi
}

for i in {1..2}; do
   sleep 1
   check_connections
   if [[ $google_good == 'true' && $vpn_good == 'true' ]]; then
       echo " 4. All done, stay inside"
       exit 0
   else
       echo "Trying again..."
   fi
done

echo " 4. Killing VPN and local DNS server (again)"
echo "nameserver 1.1.1.1" > /etc/resolv.conf
./cleanup.sh

for i in {1..5}; do
   sleep 1
   check_connections
   if [[ $google_good == 'true' && $vpn_good == 'true' ]]; then
       echo " 5. All done, stay inside"
       exit 0
   else
       echo "Trying again..."
   fi
done

echo " 5. There is an issue with coming off the VPN! You have a few options:"
echo -e "    1: Reconnect your wifi connection"
echo -e "    2: Try changing \e[33m/etc/resolv.conf\e[0m to be \e[33mnameserver 1.1.1.1\e[0m"
echo -e "    3: Try running this script again"

./debug.sh
