# The RoS Tunneller

This project handles configuring your DNS server for when your Ubuntu laptop is on the VPN or not. It also improves your Slack calls by moving network traffic off the VPN.

## How do I use it?

> **_PLEASE NOTE:_** This **replaces** how you currently connect the VPN. Do not use the "Network Manager" connection anymore; this script is how you connect to the VPN

1. Clone this repo: `git clone git@gitlab.ros.gov.uk:iac/dev-vpn-split-tunnel.git`
2. Drop off the VPN and go to https://vpn.ros.gov.uk/ to download your open VPN profile file. Copy this into the `pia` directory in this project
3. Connect using: `sudo ./run_dnsserv.sh client <ros username - case sensitive, e.g. WrightJ>`
4. Enjoy! If you have any issues, raise them in Slack in the #help-tunneller room.

## So, what does this thing do?

![Architecture](docs/architecture.jpg)

The RoS Tunneller creates a local DNS server which intercepts traffic and dynamically adds a route is that hostname is one we want to go off the VPN.

The source code is based on [a split tunneller repo](https://github.com/RoliSoft/Split-Tunnel-Host).

We've got a [more in-depth readme](./docs/README-detailed.md) if you'd like to know more.
