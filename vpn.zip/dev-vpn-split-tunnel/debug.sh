#!/bin/bash

if [ $EUID -ne 0 ]; then
    echo "This script must be run as root"
    exit 1
fi

rm -rf debug.txt
touch debug.txt

function log() {
    echo "==================== $1 ======================" >> debug.txt
    $(echo $1) >> debug.txt
    echo "===========================================================" >> debug.txt
    echo "" >> debug.txt
}

log "echo debug.txt created at $(date)"
log "cat /etc/os-release"
log "cat /etc/resolv.conf"
log "route -n"
log "lsof -i :53"
log "netstat -tunp"
log "cat dnsserv_out.txt"
log "cat openvpn_out.txt"
log "ls -l /etc/init.d"
log "tail -n 150 /var/log/syslog"
log "ps -ef"

echo -e "    Please send \e[33mdebug.txt\e[0m to the \e[33m#help-tunneller\e[0m room in Slack"